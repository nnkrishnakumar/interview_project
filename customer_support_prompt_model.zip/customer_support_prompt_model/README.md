2nd assigment:

step 1: 
    openai.api_key = "YOUR_API_KEY"           # replace with openai api key and run the below command

    start the server:
        python app.py

step 2:
    Open your browser and go to http://127.0.0.1:5000